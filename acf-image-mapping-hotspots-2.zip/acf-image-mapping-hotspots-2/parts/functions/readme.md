#Functions Folder
ONE function or class per file >:O . These are a collection of helper functions.
