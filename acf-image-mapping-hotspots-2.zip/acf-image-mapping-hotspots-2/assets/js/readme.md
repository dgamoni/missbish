#Javascript Folder
All the generated javascript files go in here. You can generate them by running the __gulp js__.
