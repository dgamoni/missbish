#Images Folder
All the site images should go in here. You can create a gulp task for images if you like using the resources folder as a source but I prefer to export for web and devices from PS and then run it through Kraken https://kraken.io/web-interface.
